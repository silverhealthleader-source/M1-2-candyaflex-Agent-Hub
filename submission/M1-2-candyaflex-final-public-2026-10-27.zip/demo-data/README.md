# 실제 운영자료와 무관한 가상 데이터 120개

실제 교육 실적을 공개하지 않고 평가자가 재현할 수 있도록 생성했습니다. Firestore 에뮬레이터에서만 연습하세요. 운영 Firestore에 가져오지 않습니다.

저장소 루트의 실행환경-README.md에 따라 venv·Firebase 에뮬레이터를 준비합니다. 실행 위치는 압축을 푼 프로젝트 루트입니다. 이 ZIP에는 이미 가상 데이터 120개가 있으므로 새로 생성할 필요가 없습니다.

```powershell
$env:FIREBASE_PROJECT_ID = 'demo-candy-a-academy'
$env:FIRESTORE_EMULATOR_HOST = '127.0.0.1:8088'
.\.venv\Scripts\python.exe backend/scripts/import_data.py --data-dir demo-data
.\.venv\Scripts\python.exe backend/scripts/import_data.py --data-dir demo-data --apply
```

먼저 검증만 실행한 뒤 에뮬레이터 연결을 확인하고 --apply를 실행합니다. 생성 코드는 backend/scripts/generate_demo.py입니다. 실제 운영 DB 검증 결과는 실행검증.md에 따로 있습니다.
